const express = require('express');
const axios = require('axios');
const app = express();
const port = 3000;

// Middleware to serve static files
app.use(express.static('public'));

// Middleware to parse incoming JSON requests
app.use(express.json());

// Define route for Kimi API interaction
app.post('/chat', async (req, res) => {
  const userMessage = req.body.message;

  try {
    const response = await axios.post('https://api.moonshot.cn/v1/chat/completions', {
      model: "moonshot-v1-8k",
      messages: [
        { role: "system", content: "你是 Kimi，由 Moonshot AI 提供的人工智能助手，你更擅长中文和英文的对话。" },
        { role: "user", content: userMessage }
      ],
      temperature: 0.3,
    }, {
      headers: {
        'Authorization': 'Bearer sk-qOoUHf6q3OG9D99WwTg2IBDHvn7vmRZDNvEmsdrrVUAENbl5',
        'Content-Type': 'application/json'
      }
    });

    // Send the API response back to the frontend
    res.json({ reply: response.data.choices[0].message.content });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error occurred while contacting the API');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

